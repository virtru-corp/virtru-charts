Postman Collection Utilities

- [Entitle one or more Non Person Entities (NPES) with all attributes](./npe-all.postman_collection.json)

For re-use - this folder is archived and under source control for downloading by consumers.

```
tar czf postman.tar.gz postman  
```